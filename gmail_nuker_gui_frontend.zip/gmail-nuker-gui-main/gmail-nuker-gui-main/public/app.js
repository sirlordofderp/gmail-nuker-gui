const armButton = document.getElementById('armButton');
const fireButton = document.getElementById('fireButton');
const confirmText = document.getElementById('confirmText');
const logBox = document.getElementById('log');

function selectedCategories() {
  return [...document.querySelectorAll('.toggles input[type="checkbox"]:checked')]
    .map((box) => box.value);
}

function log(message) { logBox.textContent = message; }
function pretty(obj) { return JSON.stringify(obj, null, 2); }
function setArmed(enabled) { fireButton.disabled = !(enabled && confirmText.value.trim() === 'FIRE'); }

confirmText.addEventListener('input', () => setArmed(window.__armed === true));

document.querySelectorAll('.toggles input').forEach((box) => {
  box.addEventListener('change', () => {
    window.__armed = false;
    setArmed(false);
    log('Targets changed. Press ARM again before FIRE.');
  });
});

armButton.addEventListener('click', async () => {
  const categories = selectedCategories();
  if (categories.length === 0) {
    log('Pick at least one target first.');
    return;
  }

  window.__armed = false;
  setArmed(false);
  log('ARMING... scanning selected Gmail categories only. No deletion happening.');

  try {
    const res = await fetch('/api/arm', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ categories }),
    });
    const data = await res.json();
    if (!data.ok) throw new Error(data.error || 'ARM failed.');

    window.__armed = true;
    setArmed(true);
    log('ARMED. Test scan complete.\n\n' +
      `Total messages locked on target: ${data.arm.total}\n\n` +
      pretty(data.arm.categories) +
      '\n\nType FIRE, then hit the big red button if you really want them permanently deleted.'
    );
  } catch (err) {
    log(`ARM failed: ${err.message}`);
  }
});

fireButton.addEventListener('click', async () => {
  const categories = selectedCategories();
  if (confirmText.value.trim() !== 'FIRE') {
    log('Type FIRE in the confirmation box first.');
    return;
  }

  fireButton.disabled = true;
  armButton.disabled = true;
  log('FIRING... permanent Gmail deletion in progress. Do not close this window.');

  try {
    const res = await fetch('/api/fire', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ categories, confirm: confirmText.value.trim() }),
    });
    const data = await res.json();
    if (!data.ok) throw new Error(data.error || 'FIRE failed.');

    window.__armed = false;
    confirmText.value = '';
    setArmed(false);
    log('🔥 FIRE COMPLETE.\n\n' +
      `Deleted: ${data.result.deleted}\n` +
      `Expected from ARM scan: ${data.result.expected}\n\n` +
      pretty(data.result.categories)
    );
  } catch (err) {
    log(`FIRE failed: ${err.message}`);
  } finally {
    armButton.disabled = false;
  }
});
