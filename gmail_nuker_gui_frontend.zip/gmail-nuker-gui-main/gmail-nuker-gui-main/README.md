# Gmail Nuker GUI

A silly local web GUI for bulk-cleaning Gmail categories.

## Run

1. Put your Gmail OAuth `credentials.json` next to `gui.js`.
2. Run:

```bash
npm install
npm start
```

3. Open `http://localhost:3434`.

## Controls

- **ARM** scans selected categories and shows counts. It does not delete anything.
- **FIRE!!** permanently deletes the exact categories you armed.
- If you change toggles after ARM, you must ARM again.
- You must type `FIRE` in the confirmation box before the red button unlocks.

## CLI fallback

```bash
npm run cli
```
