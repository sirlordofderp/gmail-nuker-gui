const fs = require('fs');
const path = require('path');
const http = require('http');
const url = require('url');
const readline = require('readline');
const { google } = require('googleapis');

const SCOPES = ['https://mail.google.com/'];
const TOKEN_PATH = path.join(__dirname, 'token.json');
const CREDENTIALS_PATH = path.join(__dirname, 'credentials.json');
const PORT = Number(process.env.PORT || 3434);

const CATEGORY_MAP = {
  promotions: { label: 'Promotions', query: 'category:promotions' },
  social: { label: 'Social', query: 'category:social' },
  updates: { label: 'Updates', query: 'category:updates' },
  forums: { label: 'Forums', query: 'category:forums' },
  primary: { label: 'Primary', query: 'category:primary' },
  spam: { label: 'Spam', labelIds: ['SPAM'] },
};

let lastArm = null;

function ask(question) {
  return new Promise((resolve) => {
    const rl = readline.createInterface({ input: process.stdin, output: process.stdout });
    rl.question(question, (answer) => {
      rl.close();
      resolve((answer || '').trim());
    });
  });
}

async function authorize() {
  let content;
  try {
    content = fs.readFileSync(CREDENTIALS_PATH, 'utf8');
  } catch (err) {
    console.error('❌ Missing credentials.json. Put it next to gui.js first.');
    process.exit(1);
  }

  const credentials = JSON.parse(content);
  const { client_secret, client_id, redirect_uris } = credentials.installed || credentials.web;
  const redirectUri = (redirect_uris && redirect_uris[0]) || 'http://localhost';
  const oAuth2Client = new google.auth.OAuth2(client_id, client_secret, redirectUri);

  try {
    const token = fs.readFileSync(TOKEN_PATH, 'utf8');
    oAuth2Client.setCredentials(JSON.parse(token));
    return oAuth2Client;
  } catch (_) {
    const authUrl = oAuth2Client.generateAuthUrl({
      access_type: 'offline',
      scope: SCOPES,
    });
    console.log('\n🔑 First run setup');
    console.log('Open this URL, authorize Gmail, then paste the code here:\n');
    console.log(authUrl);
    const code = await ask('\n📥 Code: ');
    const { tokens } = await oAuth2Client.getToken(code);
    oAuth2Client.setCredentials(tokens);
    fs.writeFileSync(TOKEN_PATH, JSON.stringify(tokens, null, 2));
    console.log('✅ Token saved to token.json');
    return oAuth2Client;
  }
}

function selectedToFilters(selected) {
  const safe = Array.isArray(selected) ? selected : [];
  return safe
    .filter((key) => Object.prototype.hasOwnProperty.call(CATEGORY_MAP, key))
    .map((key) => ({ key, ...CATEGORY_MAP[key] }));
}

async function collectMessageIds(auth, filter) {
  const gmail = google.gmail({ version: 'v1', auth });
  const ids = [];
  let pageToken;

  do {
    const res = await gmail.users.messages.list({
      userId: 'me',
      maxResults: 500,
      q: filter.query || undefined,
      labelIds: filter.labelIds || undefined,
      pageToken: pageToken || undefined,
    });

    const messages = res.data.messages || [];
    ids.push(...messages.map((m) => m.id));
    pageToken = res.data.nextPageToken;
  } while (pageToken);

  return ids;
}

async function armCategories(auth, selected) {
  const filters = selectedToFilters(selected);
  if (filters.length === 0) {
    throw new Error('No categories selected.');
  }

  const result = {
    armedAt: new Date().toISOString(),
    selected: filters.map((f) => f.key),
    categories: {},
    total: 0,
  };

  for (const filter of filters) {
    const ids = await collectMessageIds(auth, filter);
    result.categories[filter.key] = {
      label: filter.label,
      count: ids.length,
      ids,
    };
    result.total += ids.length;
  }

  lastArm = result;
  return summarizeArm(result);
}

function summarizeArm(arm) {
  return {
    armedAt: arm.armedAt,
    selected: arm.selected,
    total: arm.total,
    categories: Object.fromEntries(
      Object.entries(arm.categories).map(([key, value]) => [
        key,
        { label: value.label, count: value.count },
      ])
    ),
  };
}

async function batchDeleteMessages(auth, ids) {
  const gmail = google.gmail({ version: 'v1', auth });
  const chunkSize = 1000;
  let deleted = 0;

  for (let i = 0; i < ids.length; i += chunkSize) {
    const chunk = ids.slice(i, i + chunkSize);
    if (chunk.length === 0) continue;

    await gmail.users.messages.batchDelete({
      userId: 'me',
      requestBody: { ids: chunk },
    });

    deleted += chunk.length;
  }

  return deleted;
}

async function fire(auth, selected) {
  const wanted = selectedToFilters(selected).map((f) => f.key);
  if (wanted.length === 0) {
    throw new Error('No categories selected.');
  }

  if (!lastArm) {
    throw new Error('Press ARM first. ARM is the test scan and safety latch.');
  }

  const sameSelection =
    wanted.length === lastArm.selected.length &&
    wanted.every((key) => lastArm.selected.includes(key));

  if (!sameSelection) {
    throw new Error('Category toggles changed after ARM. Press ARM again before FIRE.');
  }

  const total = lastArm.total;
  let deleted = 0;
  const perCategory = {};

  for (const [key, data] of Object.entries(lastArm.categories)) {
    const count = await batchDeleteMessages(auth, data.ids);
    deleted += count;
    perCategory[key] = { label: data.label, deleted: count };
  }

  const fired = {
    firedAt: new Date().toISOString(),
    deleted,
    expected: total,
    categories: perCategory,
  };

  lastArm = null;
  return fired;
}

function sendJson(res, status, payload) {
  const body = JSON.stringify(payload, null, 2);
  res.writeHead(status, {
    'Content-Type': 'application/json',
    'Content-Length': Buffer.byteLength(body),
  });
  res.end(body);
}

function serveStatic(req, res) {
  const parsed = url.parse(req.url);
  const requested = parsed.pathname === '/' ? '/index.html' : parsed.pathname;
  const normalized = path.normalize(requested).replace(/^(\.\.[/\\])+/, '');
  const publicRoot = path.join(__dirname, 'public');
  const filePath = path.join(publicRoot, normalized);

  if (!filePath.startsWith(publicRoot)) {
    res.writeHead(403);
    res.end('Forbidden');
    return;
  }

  fs.readFile(filePath, (err, content) => {
    if (err) {
      res.writeHead(404);
      res.end('Not found');
      return;
    }

    const ext = path.extname(filePath).toLowerCase();
    const contentType =
      ext === '.html' ? 'text/html; charset=utf-8' :
      ext === '.css' ? 'text/css; charset=utf-8' :
      ext === '.js' ? 'text/javascript; charset=utf-8' :
      'application/octet-stream';

    res.writeHead(200, { 'Content-Type': contentType });
    res.end(content);
  });
}

function readBody(req) {
  return new Promise((resolve, reject) => {
    let data = '';
    req.on('data', (chunk) => {
      data += chunk;
      if (data.length > 1_000_000) {
        reject(new Error('Request body too large.'));
        req.destroy();
      }
    });
    req.on('end', () => {
      try {
        resolve(data ? JSON.parse(data) : {});
      } catch (err) {
        reject(new Error('Invalid JSON body.'));
      }
    });
  });
}

async function start() {
  const auth = await authorize();

  const server = http.createServer(async (req, res) => {
    try {
      const parsed = url.parse(req.url, true);

      if (req.method === 'GET' && parsed.pathname === '/api/status') {
        sendJson(res, 200, {
          ok: true,
          armed: lastArm ? summarizeArm(lastArm) : null,
          categories: Object.fromEntries(
            Object.entries(CATEGORY_MAP).map(([key, value]) => [key, value.label])
          ),
        });
        return;
      }

      if (req.method === 'POST' && parsed.pathname === '/api/arm') {
        const body = await readBody(req);
        const arm = await armCategories(auth, body.categories);
        sendJson(res, 200, { ok: true, arm });
        return;
      }

      if (req.method === 'POST' && parsed.pathname === '/api/fire') {
        const body = await readBody(req);
        const confirm = String(body.confirm || '').trim();
        if (confirm !== 'FIRE') {
          sendJson(res, 400, { ok: false, error: 'Type FIRE in the confirmation box first.' });
          return;
        }

        const result = await fire(auth, body.categories);
        sendJson(res, 200, { ok: true, result });
        return;
      }

      serveStatic(req, res);
    } catch (err) {
      sendJson(res, 500, { ok: false, error: err.message || String(err) });
    }
  });

  server.listen(PORT, () => {
    console.log(`\n🚀 Gmail Nuker GUI is live: http://localhost:${PORT}`);
    console.log('Open that in your browser. ARM scans. FIRE permanently deletes.');
  });
}

start().catch((err) => {
  console.error('❌ Fatal error:', err.message || err);
  process.exit(1);
});
